
  # Chore App with Leaderboards

  This is a code bundle for Chore App with Leaderboards. The original project is available at https://www.figma.com/design/dkPpwTQNcysdNIlXoQExer/Chore-App-with-Leaderboards.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  